Avatar assets for Kawaii style.
Poses available: tutorial-avatar.png and tutorial-avatar-2.png through tutorial-avatar-10.png.
