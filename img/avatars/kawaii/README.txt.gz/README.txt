Avatar assets for Kawaii style.
