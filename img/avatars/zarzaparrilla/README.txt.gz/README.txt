Avatar assets for Zarzaparrilla style.
